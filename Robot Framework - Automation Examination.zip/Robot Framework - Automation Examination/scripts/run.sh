#!/bin/bash

# Check if running under bash, not sh
if [ -z "$BASH_VERSION" ]; then
  echo "❌ Please run this script with bash, not sh."
  echo "Try: bash $0 \"$@\""
  exit 1
fi

VALID_ENVS=("sit" "uat")
ENV=""
TAGS=""
FILES=()
TESTCASE=""

usage() {
  echo "Usage: $0 [-e environment] [-t tags] [-f files] [-c testcase]"
  echo "  -e environment   Environment to run tests in (sit, uat)"
  echo "  -t tags          Robot Framework tags to include (e.g. Smoke or Tag1ANDTag2)"
  echo "  -f files         One or more test files (space separated if multiple)"
  echo "  -c testcase      Single testcase name to run"
  echo
  echo "Examples:"
  echo "  $0                     # run all tests, no env"
  echo "  $0 -e sit              # all tests, env=sit"
  echo "  $0 -f test1.robot      # run a single file, no env"
  echo "  $0 -f test1.robot test2.robot -e uat  # multiple files with env"
  echo "  $0 -t Smoke            # run by tag, no env"
  echo "  $0 -c 'Login Test'     # run single testcase by name"
  echo "  $0 -c 'Login Test' -e sit  # testcase with env"
  exit 1
}

# Parse args
while [[ $# -gt 0 ]]; do
  key="$1"
  case $key in
    -e|--env)
      ENV="$2"
      shift 2
      ;;
    -t|--tags)
      TAGS="$2"
      shift 2
      ;;
    -f|--files)
      shift
      while [[ $# -gt 0 && ! "$1" =~ ^- ]]; do
        FILES+=("$1")
        shift
      done
      ;;
    -c|--testcase)
      TESTCASE="$2"
      shift 2
      ;;
    -h|--help)
      usage
      ;;
    *)
      echo "Unknown option: $1"
      usage
      ;;
  esac
done

# Validate environment if set
if [[ -n "$ENV" ]]; then
  if [[ ! " ${VALID_ENVS[@]} " =~ " ${ENV} " ]]; then
    echo "Invalid environment: '${ENV}'. Allowed values are: ${VALID_ENVS[*]}"
    exit 1
  fi
fi

# Basic validation for tags
if [[ -n "$TAGS" && "$TAGS" =~ ^- ]]; then
  echo "Invalid tag argument: '${TAGS}'"
  exit 1
fi

# Resolve absolute path of this script, robustly
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TEST_DIR="${SCRIPT_DIR}/../testcases"
RESULTS_DIR="${SCRIPT_DIR}/../results"

# Create results directory if not exist
mkdir -p "$RESULTS_DIR"

# Check testcases directory
if [[ ! -d "$TEST_DIR" ]]; then
  echo "Test directory '${TEST_DIR}' not found. Exiting."
  exit 1
fi

# Validate files if any specified
for file in "${FILES[@]}"; do
  if [[ ! -f "${TEST_DIR}/${file}" ]]; then
    echo "File '${file}' does not exist in '${TEST_DIR}'. Exiting."
    exit 1
  fi
done

echo "Environment: ${ENV:-none}"
echo "Tags: ${TAGS:-none}"
echo "Testcase: ${TESTCASE:-none}"
if [ ${#FILES[@]} -eq 0 ]; then
  echo "Files: all tests"
else
  echo "Files: ${FILES[*]}"
fi

echo "************************ go to test directory **********************"
cd "$TEST_DIR" || { echo "Failed to cd to test directory. Exiting."; exit 1; }
pwd

echo "************************* Start Testing ****************************************"

ROBOT_ARGS=()
ROBOT_ARGS+=(--outputdir "$RESULTS_DIR")

if [[ -n "$ENV" ]]; then
  ROBOT_ARGS+=(--variable "env:${ENV}")
fi

if [[ -n "$TAGS" ]]; then
  ROBOT_ARGS+=(--include "$TAGS")
fi

if [[ -n "$TESTCASE" ]]; then
  ROBOT_ARGS+=(--test "$TESTCASE")
fi

if [[ ${#FILES[@]} -gt 0 ]]; then
  ROBOT_ARGS+=("${FILES[@]}")
else
  ROBOT_ARGS+=("*.robot")
fi

robot "${ROBOT_ARGS[@]}"
RET_CODE=$?

if [[ $RET_CODE -ne 0 ]]; then
  echo "Robot tests failed with exit code $RET_CODE"
  exit $RET_CODE
fi

if command -v robotmetrics >/dev/null 2>&1; then
  robotmetrics --inputpath "$RESULTS_DIR" --output output.xml
else
  echo "Warning: robotmetrics command not found, skipping metrics generation."
fi

echo "************************** published results *************************"
